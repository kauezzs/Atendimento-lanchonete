import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Servidor web do Sistema da Lanchonete.
 *
 * Como rodar:
 *   1) Deixe este arquivo, o index.html e o style.css na MESMA pasta.
 *   2) javac LanchoneteServer.java
 *   3) java LanchoneteServer
 *   4) Acesse http://localhost:8080  (senha: 1234)
 *
 * Observação: para simplificar (é um projeto didático, single-user),
 * o estado de login e o carrinho ficam em memória, sem sessões/cookies.
 */
public class LanchoneteServer {

    private static boolean autenticado = false;
    private static final List<ItemPedido> carrinho = new ArrayList<>();

    static class ItemPedido {
        final String nome;
        final double preco;
        final int quantidade;

        ItemPedido(String nome, double preco, int quantidade) {
            this.nome = nome;
            this.preco = preco;
            this.quantidade = quantidade;
        }
    }

    public static void main(String[] args) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(8080), 0);

        server.createContext("/", LanchoneteServer::handleIndex);
        server.createContext("/style.css", LanchoneteServer::handleCss);
        server.createContext("/login", LanchoneteServer::handleLogin);
        server.createContext("/menu", LanchoneteServer::handleMenu);
        server.createContext("/adicionar", LanchoneteServer::handleAdicionar);
        server.createContext("/finalizar", LanchoneteServer::handleFinalizar);

        server.setExecutor(null);
        server.start();

        System.out.println("Servidor rodando em http://localhost:8080");
    }

    // ===================== ROTAS =====================

    private static void handleIndex(HttpExchange exchange) throws IOException {
        if (autenticado) {
            redirecionar(exchange, "/menu");
            return;
        }

        String query = exchange.getRequestURI().getQuery();
        String mensagem = (query != null && query.contains("erro=1"))
                ? "<p class=\"erro\">Senha incorreta!</p>"
                : "";

        String html = lerArquivo("index.html").replace("{{MENSAGEM}}", mensagem);
        responderHtml(exchange, html);
    }

    private static void handleCss(HttpExchange exchange) throws IOException {
        byte[] bytes = Files.readAllBytes(Path.of("style.css"));
        exchange.getResponseHeaders().add("Content-Type", "text/css; charset=UTF-8");
        exchange.sendResponseHeaders(200, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    private static void handleLogin(HttpExchange exchange) throws IOException {
        Map<String, String> form = lerFormulario(exchange);
        String senha = form.getOrDefault("senha", "");

        if (senha.equals("1234")) {
            autenticado = true;
            carrinho.clear();
            redirecionar(exchange, "/menu");
        } else {
            redirecionar(exchange, "/?erro=1");
        }
    }

    private static void handleMenu(HttpExchange exchange) throws IOException {
        if (!autenticado) {
            redirecionar(exchange, "/");
            return;
        }

        StringBuilder itensHtml = new StringBuilder();
        double subtotalAtual = 0;

        for (ItemPedido item : carrinho) {
            double totalItem = item.preco * item.quantidade;
            subtotalAtual += totalItem;
            itensHtml.append("<li>")
                    .append(item.quantidade).append("x ").append(item.nome)
                    .append(" - R$ ").append(String.format("%.2f", totalItem))
                    .append("</li>");
        }

        String html = "<!DOCTYPE html>"
                + "<html lang=\"pt-br\"><head><meta charset=\"UTF-8\">"
                + "<title>Cardápio - Lanchonete</title>"
                + "<link rel=\"stylesheet\" href=\"/style.css\"></head><body>"
                + "<div class=\"card\">"
                + "<h1>Cardápio</h1>"
                + "<form method=\"POST\" action=\"/adicionar\">"
                + "<label for=\"produto\">Produto:</label>"
                + "<select id=\"produto\" name=\"produto\">"
                + "<option value=\"1\">Hambúrguer - R$ 15,00</option>"
                + "<option value=\"2\">Pizza - R$ 20,00</option>"
                + "<option value=\"3\">Refrigerante - R$ 6,00</option>"
                + "<option value=\"4\">Batata Frita - R$ 10,00</option>"
                + "</select>"
                + "<label for=\"quantidade\">Quantidade:</label>"
                + "<input type=\"number\" id=\"quantidade\" name=\"quantidade\" min=\"1\" value=\"1\">"
                + "<button type=\"submit\">Adicionar</button>"
                + "</form>"
                + "<h1>Pedido atual</h1>"
                + "<ul>" + itensHtml + "</ul>"
                + "<p>Subtotal: R$ " + String.format("%.2f", subtotalAtual) + "</p>"
                + "<form method=\"POST\" action=\"/finalizar\">"
                + "<button type=\"submit\">Finalizar pedido</button>"
                + "</form>"
                + "</div></body></html>";

        responderHtml(exchange, html);
    }

    private static void handleAdicionar(HttpExchange exchange) throws IOException {
        if (!autenticado) {
            redirecionar(exchange, "/");
            return;
        }

        Map<String, String> form = lerFormulario(exchange);
        int produto = Integer.parseInt(form.getOrDefault("produto", "0"));
        int quantidade = Math.max(Integer.parseInt(form.getOrDefault("quantidade", "1")), 1);

        String nome;
        double preco;

        // switch identifica o produto escolhido e define o preço
        switch (produto) {
            case 1: nome = "Hambúrguer";    preco = 15.00; break;
            case 2: nome = "Pizza";         preco = 20.00; break;
            case 3: nome = "Refrigerante";  preco = 6.00;  break;
            case 4: nome = "Batata Frita";  preco = 10.00; break;
            default:
                // opção inválida: ignora e volta para o cardápio
                redirecionar(exchange, "/menu");
                return;
        }

        carrinho.add(new ItemPedido(nome, preco, quantidade));
        redirecionar(exchange, "/menu");
    }

    private static void handleFinalizar(HttpExchange exchange) throws IOException {
        if (!autenticado) {
            redirecionar(exchange, "/");
            return;
        }

        double subtotal = 0;
        int totalItens = 0;

        for (ItemPedido item : carrinho) {
            subtotal += item.preco * item.quantidade;
            totalItens += item.quantidade;
        }

        // operador ternário obrigatório para o desconto
        double desconto = (subtotal >= 50.00) ? subtotal * 0.10 : 0.0;
        double total = subtotal - desconto;

        // for mostrando a sequência de produtos registrados
        StringBuilder registrados = new StringBuilder();
        for (int i = 1; i <= totalItens; i++) {
            registrados.append("<li>Produto ").append(i).append(" registrado</li>");
        }

        String html = "<!DOCTYPE html>"
                + "<html lang=\"pt-br\"><head><meta charset=\"UTF-8\">"
                + "<title>Relatório - Lanchonete</title>"
                + "<link rel=\"stylesheet\" href=\"/style.css\"></head><body>"
                + "<div class=\"card\">"
                + "<h1>Relatório do pedido</h1>"
                + "<ul>" + registrados + "</ul>"
                + "<p>Quantidade total de itens: " + totalItens + "</p>"
                + "<p>Subtotal: R$ " + String.format("%.2f", subtotal) + "</p>"
                + "<p>Desconto: R$ " + String.format("%.2f", desconto) + "</p>"
                + "<p class=\"total\">Total: R$ " + String.format("%.2f", total) + "</p>"
                + "<a class=\"botao\" href=\"/\">Novo pedido</a>"
                + "</div></body></html>";

        carrinho.clear();
        autenticado = false; // exige a senha novamente no próximo pedido
        responderHtml(exchange, html);
    }

    // ===================== UTILITÁRIOS =====================

    private static void redirecionar(HttpExchange exchange, String local) throws IOException {
        exchange.getResponseHeaders().add("Location", local);
        exchange.sendResponseHeaders(302, -1);
        exchange.close();
    }

    private static void responderHtml(HttpExchange exchange, String html) throws IOException {
        byte[] bytes = html.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().add("Content-Type", "text/html; charset=UTF-8");
        exchange.sendResponseHeaders(200, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    private static String lerArquivo(String caminho) throws IOException {
        return Files.readString(Path.of(caminho), StandardCharsets.UTF_8);
    }

    private static Map<String, String> lerFormulario(HttpExchange exchange) throws IOException {
        String corpo = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
        Map<String, String> dados = new HashMap<>();

        for (String par : corpo.split("&")) {
            if (par.isEmpty()) continue;
            String[] partes = par.split("=", 2);
            String chave = URLDecoder.decode(partes[0], StandardCharsets.UTF_8);
            String valor = partes.length > 1 ? URLDecoder.decode(partes[1], StandardCharsets.UTF_8) : "";
            dados.put(chave, valor);
        }
        return dados;
    }
}
